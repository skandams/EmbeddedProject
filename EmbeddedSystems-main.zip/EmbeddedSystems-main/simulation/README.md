# Activity1, Activity2, Activity3 and Activity4 

|ON|OFF|
|:--:|:--:|
|![image](https://user-images.githubusercontent.com/42568338/116530077-3e468a00-a8fb-11eb-802d-8837b8b27ffe.png)|![image](https://user-images.githubusercontent.com/42568338/116530100-443c6b00-a8fb-11eb-8db3-3f00ee57b6f0.png)|


