# EmbeddedSystems

[![Compile-Linux](https://github.com/skandams/EmbeddedSystems/actions/workflows/Compile.yml/badge.svg)](https://github.com/skandams/EmbeddedSystems/actions/workflows/Compile.yml)
[![Cppcheck](https://github.com/skandams/EmbeddedSystems/actions/workflows/CodeQulaity.yml/badge.svg)](https://github.com/skandams/EmbeddedSystems/actions/workflows/CodeQulaity.yml)
