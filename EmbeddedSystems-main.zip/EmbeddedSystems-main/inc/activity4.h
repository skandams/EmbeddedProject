#ifndef _ACTIVITY4_H_
#define _ACTIVITY4_H_


void USARTInit(void);

/**
 * @brief Function to Read character
 *
 */
//char USARTReadChar();

/**
 * @brief Function to write character
 * @param[in] a single character
 */
//void USARTWriteChar(char);

/**
 * @brief Function to write string
 * @param[in] a single character
 */
void USARTWriteString(char);

#endif  /* _ACTIVITY4_H_ */
